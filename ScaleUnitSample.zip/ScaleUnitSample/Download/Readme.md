###This folder is a container for the:
1. Sealed Scale Unit installer downloaded from LCS,
2. Channel Demo Data nuget package downloaded from the public nuget,
3. Channel DB configuration file downloaded from HQ.