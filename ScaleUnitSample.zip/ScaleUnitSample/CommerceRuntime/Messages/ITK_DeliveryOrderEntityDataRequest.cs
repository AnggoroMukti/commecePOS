﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITK.CommerceRuntime.Messages
{
    using System.Runtime.Serialization;
    using Microsoft.Dynamics.Commerce.Runtime.Messages;

    /// <summary>
    /// A simple request class to get all DeliveryOrder  Entities.
    /// </summary>
    [DataContract]
    public sealed class ITK_DeliveryOrderEntityDataRequest : Request
    {
    }
}
