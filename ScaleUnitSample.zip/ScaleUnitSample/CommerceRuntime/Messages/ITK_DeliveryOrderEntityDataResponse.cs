﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITK.CommerceRuntime.Messages
{
    using System.Runtime.Serialization;
    //using ITK.CommerceRuntime.Entities;
    using ITK.CommerceRuntime.Entities.DataModel;
    using Microsoft.Dynamics.Commerce.Runtime;
    using Microsoft.Dynamics.Commerce.Runtime.Messages;

    /// <summary>
    /// Defines a simple response class that holds a collection of Example Entities.
    /// </summary>
    [DataContract]
    public sealed class ITK_DeliveryOrderEntityDataResponse : Response
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ITK_DeliveryOrderEntityDataResponse"/> class.
        /// </summary>
        /// <param name="ITK_DeliveryOrderEntities">The collection of ITK_DeliveryOrder Entities.</param>
        public ITK_DeliveryOrderEntityDataResponse(PagedResult<ITK_DeliveryOrderEntity> ITK_DeliveryOrderEntities)
        {
            this.ITK_DeliveryOrderEntities = ITK_DeliveryOrderEntities;
        }

        /// <summary>
        /// Gets the retrieved Example Entities as a paged result.
        /// </summary>
        [DataMember]
        public PagedResult<ITK_DeliveryOrderEntity> ITK_DeliveryOrderEntities { get; private set; }
    }
}
