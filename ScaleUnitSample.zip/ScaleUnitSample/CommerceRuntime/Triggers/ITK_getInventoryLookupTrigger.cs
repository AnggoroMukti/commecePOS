﻿using Microsoft.Dynamics.Commerce.Runtime;
using Microsoft.Dynamics.Commerce.Runtime.Data;
using Microsoft.Dynamics.Commerce.Runtime.DataModel;
using Microsoft.Dynamics.Commerce.Runtime.DataServices.Messages;
using Microsoft.Dynamics.Commerce.Runtime.Messages;
using Microsoft.Dynamics.Commerce.Runtime.RealtimeServices.Messages;
using Microsoft.Dynamics.Commerce.Runtime.Services.Messages;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text.Json;
using System.Threading.Tasks;
using static Azure.Core.HttpHeader;

public class ITK_getInventoryLookupTrigger : IRequestTriggerAsync
{
    /// <summary>
    /// Gets the supported requests for this trigger.
    /// </summary>
    public IEnumerable<Type> SupportedRequestTypes
    {
        get
        {
            return new[] { typeof(SearchOrgUnitAvailabilitiesServiceRequest) };
        }
    }

    public class Params
    {
        public string item { get; set; }
        public string warehouse { get; set; }
    }
    /// <summary>
    /// Post trigger code.
    /// </summary>
    /// <param name="request">The request.</param>
    /// <param name="response">The response.</param>
    public async Task OnExecuted(Request request, Response response)
    {
        ThrowIf.Null(request, "request");
        ThrowIf.Null(response, "response");
        

        if ((request is SearchOrgUnitAvailabilitiesServiceRequest) && (response is EntityDataServiceResponse<OrgUnitAvailability>))
        {
            EntityDataServiceResponse<OrgUnitAvailability> responseV1 = response as EntityDataServiceResponse<OrgUnitAvailability>;

            foreach (OrgUnitAvailability orgItem in responseV1)
            {
                foreach (ItemAvailability itemAvail in orgItem.ItemAvailabilities)
                {
                    var parm2FO = new Params { item = itemAvail.ItemId, warehouse = itemAvail.InventoryLocationId };
                    string parm2FOs = JsonSerializer.Serialize(parm2FO);

                    InvokeExtensionMethodRealtimeRequest extensionRequest = new InvokeExtensionMethodRealtimeRequest("getInventoryStock", parm2FOs);
                    //InvokeExtensionMethodRealtimeRequest extensionRequest = new InvokeExtensionMethodRealtimeRequest("SerialCheck", "24009187");
                    InvokeExtensionMethodRealtimeResponse responseFO = await request.RequestContext.ExecuteAsync<InvokeExtensionMethodRealtimeResponse>(extensionRequest).ConfigureAwait(false);
                    ReadOnlyCollection<object> results = responseFO.Result;

                    int unitInPart = (int)results[0];
                    int availReserv = (int)results[1];
                    int phyAvail = (int)results[2];                    

                    //CommerceProperty unitInPartProp = new CommerceProperty();
                    //unitInPartProp.Key = "UnitInPart";
                    //unitInPartProp.Value = new CommercePropertyValue();
                    //unitInPartProp.Value.IntegerValue = unitInPart;

                    //itemAvail.ExtensionProperties = new List<CommerceProperty>
                    //{
                    //    unitInPartProp
                    //};

                    itemAvail.ExtensionProperties.Add(new CommerceProperty()
                    {
                        Key = "UnitInPart",
                        Value = unitInPart
                    });
                    itemAvail.ExtensionProperties.Add(new CommerceProperty()
                    {
                        Key = "AvailReserv",
                        Value = availReserv + unitInPart
                    });
                    itemAvail.ExtensionProperties.Add(new CommerceProperty()
                    {
                        Key = "PhyAvail",
                        Value = phyAvail + unitInPart
                    });
                }                
            }                        
        }
    }

/// <summary>
/// Pre trigger code
/// </summary>
/// <param name="request">The request.</param>
    public Task OnExecuting(Request request)
    {
        return Task.CompletedTask;
    }
}