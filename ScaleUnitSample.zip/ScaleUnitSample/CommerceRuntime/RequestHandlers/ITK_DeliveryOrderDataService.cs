﻿

namespace CommerceRuntime.RequestHandlers
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.Dynamics.Commerce.Runtime;
    using Microsoft.Dynamics.Commerce.Runtime.Data;
    using Microsoft.Dynamics.Commerce.Runtime.DataAccess.SqlServer;
    using Microsoft.Dynamics.Commerce.Runtime.Messages;
    using ITK.CommerceRuntime.Entities.DataModel;    
    using ITK.CommerceRuntime.Messages;

    public class ITK_DeliveryOrderDataService : IRequestHandlerAsync
    {
        public IEnumerable<Type> SupportedRequestTypes
        {
            get
            {
                return new[]
                {
                    typeof(ITK_DeliveryOrderEntityDataRequest)
                };
            }
        }

        public Task<Response> Execute(Request request)
        {
            ThrowIf.Null(request, nameof(request));

            switch (request)
            {                
                case ITK_DeliveryOrderEntityDataRequest ITK_DeliveryOrderEntityDataRequest:
                    return this.GetDeliveryOrderEntities(ITK_DeliveryOrderEntityDataRequest);                
                default:
                    throw new NotSupportedException($"Request '{request.GetType()}' is not supported.");
            }
        }

        private async Task<Response> GetDeliveryOrderEntities(ITK_DeliveryOrderEntityDataRequest request)
        {
            ThrowIf.Null(request, "request");

            using (DatabaseContext databaseContext = new DatabaseContext(request.RequestContext))
            {
                var query = new SqlPagedQuery(request.QueryResultSettings)
                {
                    DatabaseSchema = "ext",
                    Select = new ColumnSet("ITK_DELIVERYNO"),
                    From = "ITK_DELIVERYTABLE",
                    OrderBy = "ITK_DELIVERYNO",
                };

                var queryResults =
                    await databaseContext
                    .ReadEntityAsync<ITK_DeliveryOrderEntity>(query)
                    .ConfigureAwait(continueOnCapturedContext: false);
                return new ITK_DeliveryOrderEntityDataResponse(queryResults);
            }
        }
    }
}
