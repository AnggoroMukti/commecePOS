﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITK.CommerceRuntime.Entities.DataModel
{
    using System.Runtime.Serialization;
    using Microsoft.Dynamics.Commerce.Runtime.ComponentModel.DataAnnotations;
    using Microsoft.Dynamics.Commerce.Runtime.DataModel;
    using SystemAnnotations = System.ComponentModel.DataAnnotations;

    /// <summary>
    /// Defines a simple class that holds information about opening and closing times for a particular day.
    /// </summary>
    public class ITK_DeliveryOrderEntity : CommerceEntity
    {        
        private const string DeliveryNoColumn = "DELIVERYNO";        

        /// <summary>
        /// Initializes a new instance of the <see cref="ExampleEntity"/> class.
        /// </summary>
        public ITK_DeliveryOrderEntity()
            : base("DeliveryOrderNo")
        {
        }

        /// <summary>
        /// Gets or sets a property containing a string value.
        /// </summary>
        /// 
        [SystemAnnotations.Key]
        [DataMember]
        [Column(DeliveryNoColumn)]
        public string DOData
        {
            get { return (string)this[DeliveryNoColumn]; }
            set { this[DeliveryNoColumn] = value; }
        }
        
    }
}
