﻿namespace ITK.CommerceRuntime.Controllers
{
    using System.Threading.Tasks;
    using Microsoft.Dynamics.Commerce.Runtime;
    using Microsoft.Dynamics.Commerce.Runtime.DataModel;
    using Microsoft.Dynamics.Commerce.Runtime.Hosting.Contracts;

    /// <summary>
    /// An extension controller to handle requests to the StoreHours entity set.
    /// </summary>
    [RoutePrefix("ITK_DOController")]
    [BindEntity(typeof(Entities.DataModel.ITK_DeliveryOrderEntity))]
    public class ITK_DOController : IController
    {
        [HttpGet]
        [Authorization(CommerceRoles.Anonymous, CommerceRoles.Application, CommerceRoles.Customer, CommerceRoles.Device, CommerceRoles.Employee, CommerceRoles.Storefront)]
        public async Task<PagedResult<Entities.DataModel.ITK_DeliveryOrderEntity>> GetAllDONoEntities(IEndpointContext context)
        {
            var queryResultSettings = QueryResultSettings.SingleRecord;
            queryResultSettings.Paging = new PagingInfo(10);

            var request = new Messages.ITK_DeliveryOrderEntityDataRequest() { QueryResultSettings = queryResultSettings };
            var response = await context.ExecuteAsync<Messages.ITK_DeliveryOrderEntityDataResponse>(request).ConfigureAwait(false);
            return response.ITK_DeliveryOrderEntities;
        }        
    }
}
