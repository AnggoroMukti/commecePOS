System.register([], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            exports_1("default", (function (context) {
                return [
                    {
                        title: context.resources.getString("string_2"),
                        computeValue: function (row) { return row.AccountNumber; },
                        ratio: 15,
                        collapseOrder: 5,
                        minWidth: 120
                    }, {
                        title: context.resources.getString("string_3"),
                        computeValue: function (row) { return row.FullName; },
                        ratio: 20,
                        collapseOrder: 4,
                        minWidth: 200
                    }, {
                        title: context.resources.getString("string_4"),
                        computeValue: function (row) { return row.FullAddress; },
                        ratio: 25,
                        collapseOrder: 1,
                        minWidth: 200
                    }, {
                        title: context.resources.getString("string_5"),
                        computeValue: function (row) { return row.Email; },
                        ratio: 20,
                        collapseOrder: 2,
                        minWidth: 200
                    }, {
                        title: context.resources.getString("string_7"),
                        computeValue: function (row) { return row.Phone; },
                        ratio: 20,
                        collapseOrder: 3,
                        minWidth: 120
                    }
                ];
            }));
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/SearchExtension/ViewExtensions/Search/CustomCustomerSearchColumns.js.map