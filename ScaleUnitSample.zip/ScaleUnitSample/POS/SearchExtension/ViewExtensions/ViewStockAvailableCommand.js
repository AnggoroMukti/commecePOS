"use strict";
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/SearchExtension/ViewExtensions/ViewStockAvailableCommand.js.map