System.register(["PosApi/Consume/Formatters"], function (exports_1, context_1) {
    "use strict";
    var Formatters_1;
    var __moduleName = context_1 && context_1.id;
    function getItemAvailability(orgUnitAvailability) {
        "use strict";
        return (orgUnitAvailability && orgUnitAvailability.ItemAvailabilities) ? orgUnitAvailability.ItemAvailabilities[0] : undefined;
    }
    return {
        setters: [
            function (Formatters_1_1) {
                Formatters_1 = Formatters_1_1;
            }
        ],
        execute: function () {
            exports_1("default", (function (context) {
                return [
                    {
                        title: "LOCATION",
                        computeValue: function (row) {
                            return row.OrgUnitLocation.OrgUnitName;
                        },
                        ratio: 20,
                        collapseOrder: 5,
                        minWidth: 150
                    }, {
                        title: "STORE",
                        computeValue: function (row) {
                            var nonStoreWarehouseIdentifier = 0;
                            var isRetailStore = row.OrgUnitLocation.ChannelId !== nonStoreWarehouseIdentifier;
                            return Formatters_1.BooleanFormatter.toYesNo(isRetailStore);
                        },
                        ratio: 10,
                        collapseOrder: 2,
                        minWidth: 50
                    }, {
                        title: "INVENTORY",
                        computeValue: function (row) {
                            var inventoryAvailability = getItemAvailability(row);
                            var quantity = (inventoryAvailability && inventoryAvailability.AvailableQuantity) ? inventoryAvailability.AvailableQuantity : 0;
                            return quantity.toString();
                        },
                        ratio: 10,
                        collapseOrder: 6,
                        minWidth: 60,
                        isRightAligned: true
                    }, {
                        title: "RESERVED",
                        computeValue: function (row) {
                            var inventoryAvailability = getItemAvailability(row);
                            var physicalReserved = (inventoryAvailability && inventoryAvailability.PhysicalReserved) ? inventoryAvailability.PhysicalReserved : 0;
                            return physicalReserved.toString();
                        },
                        ratio: 10,
                        collapseOrder: 3,
                        minWidth: 60,
                        isRightAligned: true
                    }, {
                        title: "ORDERED",
                        computeValue: function (row) {
                            var inventoryAvailability = getItemAvailability(row);
                            var orderedSum = (inventoryAvailability && inventoryAvailability.OrderedSum) ? inventoryAvailability.OrderedSum : 0;
                            return orderedSum.toString();
                        },
                        ratio: 10,
                        collapseOrder: 4,
                        minWidth: 60,
                        isRightAligned: true
                    }, {
                        title: "UNITINPART",
                        computeValue: function (row) {
                            var inventoryAvailability = getItemAvailability(row);
                            var UnitInPart = (inventoryAvailability) ? inventoryAvailability.ExtensionProperties.filter(function (p) { return p.Key === "UnitInPart"; })[0].Value.IntegerValue : 0;
                            return UnitInPart.toString();
                        },
                        ratio: 10,
                        collapseOrder: 7,
                        minWidth: 60,
                        isRightAligned: true
                    },
                    {
                        title: "AVRESERV",
                        computeValue: function (row) {
                            var inventoryAvailability = getItemAvailability(row);
                            var AvailReserve = (inventoryAvailability) ? inventoryAvailability.ExtensionProperties.filter(function (p) { return p.Key === "AvailReserv"; })[0].Value.IntegerValue : 0;
                            return AvailReserve.toString();
                        },
                        ratio: 10,
                        collapseOrder: 8,
                        minWidth: 60,
                        isRightAligned: true
                    },
                    {
                        title: "PHYAVAIL",
                        computeValue: function (row) {
                            var inventoryAvailability = getItemAvailability(row);
                            var PhyAvail = (inventoryAvailability) ? inventoryAvailability.ExtensionProperties.filter(function (p) { return p.Key === "PhyAvail"; })[0].Value.IntegerValue : 0;
                            return PhyAvail.toString();
                        },
                        ratio: 10,
                        collapseOrder: 9,
                        minWidth: 60,
                        isRightAligned: true
                    }, {
                        title: "UNIT",
                        computeValue: function (row) {
                            var inventoryAvailability = getItemAvailability(row);
                            var unitOfMeasure = (inventoryAvailability && inventoryAvailability.UnitOfMeasure) ? inventoryAvailability.UnitOfMeasure : "";
                            return unitOfMeasure;
                        },
                        ratio: 10,
                        collapseOrder: 1,
                        minWidth: 60,
                        isRightAligned: true
                    }
                ];
            }));
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/SearchExtension/ViewExtensions/ITK_InventoryByStoreListColumns.js.map