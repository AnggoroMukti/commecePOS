System.register(["PosApi/TypeExtensions", "PosApi/Extend/Views/SearchView", "../DialogSample/MessageDialog"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var TypeExtensions_1, SearchView, MessageDialog_1, ViewCustomerSummaryCommand;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (SearchView_1) {
                SearchView = SearchView_1;
            },
            function (MessageDialog_1_1) {
                MessageDialog_1 = MessageDialog_1_1;
            }
        ],
        execute: function () {
            ViewCustomerSummaryCommand = (function (_super) {
                __extends(ViewCustomerSummaryCommand, _super);
                function ViewCustomerSummaryCommand(context) {
                    var _this = _super.call(this, context) || this;
                    _this.id = "viewCustomerSummaryCommand";
                    _this.label = context.resources.getString("string_1");
                    _this.extraClass = "iconLightningBolt";
                    _this._customerSearchResults = [];
                    _this.searchResultsSelectedHandler = function (data) {
                        _this._customerSearchResults = data.customers;
                        _this.canExecute = true;
                    };
                    _this.searchResultSelectionClearedHandler = function () {
                        _this._customerSearchResults = [];
                        _this.canExecute = false;
                    };
                    return _this;
                }
                ViewCustomerSummaryCommand.prototype.init = function (state) {
                    this.isVisible = true;
                };
                ViewCustomerSummaryCommand.prototype.execute = function () {
                    var customer = TypeExtensions_1.ArrayExtensions.firstOrUndefined(this._customerSearchResults);
                    if (!TypeExtensions_1.ObjectExtensions.isNullOrUndefined(customer)) {
                        var message = "Customer Account: " + (customer.AccountNumber || "") + " | ";
                        message += "Name: " + customer.FullName + " | ";
                        message += "Phone Number: " + customer.Phone + " | ";
                        message += "Email Address: " + customer.Email;
                        MessageDialog_1.default.show(this.context, message);
                    }
                };
                return ViewCustomerSummaryCommand;
            }(SearchView.CustomerSearchExtensionCommandBase));
            exports_1("default", ViewCustomerSummaryCommand);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/SearchExtension/ViewExtensions/ViewCustomerSummaryCommand.js.map