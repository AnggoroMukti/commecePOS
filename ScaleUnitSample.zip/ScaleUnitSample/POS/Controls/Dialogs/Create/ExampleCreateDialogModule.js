System.register(["PosApi/Create/Dialogs", "PosApi/TypeExtensions", "knockout"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Dialogs, TypeExtensions_1, knockout_1, DropdownViewModel, viewModel, ExampleCreateDialog;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Dialogs_1) {
                Dialogs = Dialogs_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            }
        ],
        execute: function () {
            DropdownViewModel = (function () {
                function DropdownViewModel() {
                    this.options = knockout_1.default.observableArray(["Option 1", "Option 2", "Option 3"]);
                    this.selectedOption = knockout_1.default.observable("");
                }
                return DropdownViewModel;
            }());
            viewModel = new DropdownViewModel();
            knockout_1.default.applyBindings(viewModel);
            ExampleCreateDialog = (function (_super) {
                __extends(ExampleCreateDialog, _super);
                function ExampleCreateDialog() {
                    var _this = _super.call(this) || this;
                    _this._data = {
                        UnusualEntityId: -1,
                        IntData: 0,
                        StringData: "",
                        ExtensionProperties: [{
                                Key: "customExtensionProp",
                                Value: {}
                            }]
                    };
                    return _this;
                }
                ExampleCreateDialog.prototype.onReady = function (element) {
                    var _this = this;
                    var intDataInput = element.querySelector("#intData");
                    intDataInput.onchange = function () { _this._data.IntData = intDataInput.valueAsNumber; };
                    var stringDataInput = element.querySelector("#stringData");
                    stringDataInput.onchange = function () { _this._data.StringData = stringDataInput.value; };
                    var extensionPropertyStringDataInput = element.querySelector("#extensionPropertyStringData");
                    extensionPropertyStringDataInput.onchange = function () {
                        _this._data.ExtensionProperties[0].Value.StringValue = extensionPropertyStringDataInput.value;
                    };
                };
                ExampleCreateDialog.prototype.open = function () {
                    var _this = this;
                    var promise = new Promise(function (resolve, reject) {
                        _this._resolve = resolve;
                        var option = {
                            title: "Create Example Entity",
                            button1: {
                                id: "btnCreate",
                                label: _this.context.resources.getString("string_2001"),
                                isPrimary: true,
                                onClick: _this.btnUpdateClickHandler.bind(_this)
                            },
                            button2: {
                                id: "btnCancel",
                                label: _this.context.resources.getString("string_2004"),
                                onClick: _this.btnCancelClickHandler.bind(_this)
                            },
                            onCloseX: function () { return _this.btnCancelClickHandler(); }
                        };
                        _this.openDialog(option);
                    });
                    return promise;
                };
                ExampleCreateDialog.prototype.btnUpdateClickHandler = function () {
                    this.resolvePromise(this._data);
                    return true;
                };
                ExampleCreateDialog.prototype.btnCancelClickHandler = function () {
                    this.resolvePromise(null);
                    return true;
                };
                ExampleCreateDialog.prototype.resolvePromise = function (editResult) {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this._resolve)) {
                        this._resolve(editResult);
                        this._resolve = null;
                    }
                };
                return ExampleCreateDialog;
            }(Dialogs.ExtensionTemplatedDialogBase));
            exports_1("default", ExampleCreateDialog);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/Controls/Dialogs/Create/ExampleCreateDialogModule.js.map