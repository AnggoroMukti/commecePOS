﻿export interface AvailableDO {    
    doNumber: string;
}