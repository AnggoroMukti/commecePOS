﻿import { Response } from "PosApi/Create/RequestHandlers";

/**
 * (Sample) Operation response of executing end of day operations.
 */
export default class EndOfDayOperationResponse extends Response { }