﻿import { ExtensionOperationRequestType, ExtensionOperationRequestHandlerBase } from "PosApi/Create/Operations";
import { ClientEntities } from "PosApi/Entities";
import EndOfDayOperationResponse from "./EndOfDayOperationResponse";
import EndOfDayOperationRequest from "./EndOfDayOperationRequest";


/**
 * (Sample) Request handler for the EndOfDayOperationRequest class.
 */
export default class EndOfDayOperationRequestHandler extends ExtensionOperationRequestHandlerBase<EndOfDayOperationResponse> {
    /**
     * Gets the supported request type.
     * @return {RequestType<TResponse>} The supported request type.
     */
    public supportedRequestType(): ExtensionOperationRequestType<EndOfDayOperationResponse> {
        return EndOfDayOperationRequest;
    }

    /**
     * Executes the request handler asynchronously.
     * @param {EndOfDayOperationRequest<TResponse>} request The request.
     * @return {Promise<ICancelableDataResult<TResponse>>} The cancelable async result containing the response.
     */
    public executeAsync(printRequest: EndOfDayOperationRequest<EndOfDayOperationResponse>): Promise<ClientEntities.ICancelableDataResult<EndOfDayOperationResponse>> {

        this.context.logger.logInformational("Log message from PrintOperationRequestHandler executeAsync().", this.context.logger.getNewCorrelationId());        
        this.context.navigator.navigate("ExampleView");
        return Promise.resolve({
                    canceled: true,
                    data: null
                    });                
    }
}