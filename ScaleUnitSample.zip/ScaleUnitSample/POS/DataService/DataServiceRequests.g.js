System.register(["PosApi/Entities", "./DataServiceEntities.g", "PosApi/Consume/DataService"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Entities_1, DataServiceEntities_g_1, DataService_1, StoreOperations, ITK_DOController, BoundController;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (DataServiceEntities_g_1_1) {
                DataServiceEntities_g_1 = DataServiceEntities_g_1_1;
            },
            function (DataService_1_1) {
                DataService_1 = DataService_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            exports_1("Entities", DataServiceEntities_g_1.Entities);
            (function (StoreOperations) {
                var SimplePingPostResponse = (function (_super) {
                    __extends(SimplePingPostResponse, _super);
                    function SimplePingPostResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return SimplePingPostResponse;
                }(DataService_1.DataServiceResponse));
                StoreOperations.SimplePingPostResponse = SimplePingPostResponse;
                var SimplePingPostRequest = (function (_super) {
                    __extends(SimplePingPostRequest, _super);
                    function SimplePingPostRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "";
                        _this._entityType = "";
                        _this._method = "SimplePingPost";
                        _this._parameters = {};
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return SimplePingPostRequest;
                }(DataService_1.DataServiceRequest));
                StoreOperations.SimplePingPostRequest = SimplePingPostRequest;
                var SimplePingGetResponse = (function (_super) {
                    __extends(SimplePingGetResponse, _super);
                    function SimplePingGetResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return SimplePingGetResponse;
                }(DataService_1.DataServiceResponse));
                StoreOperations.SimplePingGetResponse = SimplePingGetResponse;
                var SimplePingGetRequest = (function (_super) {
                    __extends(SimplePingGetRequest, _super);
                    function SimplePingGetRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "";
                        _this._entityType = "";
                        _this._method = "SimplePingGet";
                        _this._parameters = {};
                        _this._isAction = false;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return SimplePingGetRequest;
                }(DataService_1.DataServiceRequest));
                StoreOperations.SimplePingGetRequest = SimplePingGetRequest;
            })(StoreOperations || (StoreOperations = {}));
            exports_1("StoreOperations", StoreOperations);
            (function (ITK_DOController) {
                var GetAllDONoEntitiesResponse = (function (_super) {
                    __extends(GetAllDONoEntitiesResponse, _super);
                    function GetAllDONoEntitiesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetAllDONoEntitiesResponse;
                }(DataService_1.DataServiceResponse));
                ITK_DOController.GetAllDONoEntitiesResponse = GetAllDONoEntitiesResponse;
                var GetAllDONoEntitiesRequest = (function (_super) {
                    __extends(GetAllDONoEntitiesRequest, _super);
                    function GetAllDONoEntitiesRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "ITK_DOController";
                        _this._entityType = "ITK_DeliveryOrderEntity";
                        _this._method = "GetAllDONoEntities";
                        _this._parameters = {};
                        _this._isAction = false;
                        _this._returnType = DataServiceEntities_g_1.Entities.ITK_DeliveryOrderEntity;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetAllDONoEntitiesRequest;
                }(DataService_1.DataServiceRequest));
                ITK_DOController.GetAllDONoEntitiesRequest = GetAllDONoEntitiesRequest;
            })(ITK_DOController || (ITK_DOController = {}));
            exports_1("ITK_DOController", ITK_DOController);
            (function (BoundController) {
                var CreateExampleEntityResponse = (function (_super) {
                    __extends(CreateExampleEntityResponse, _super);
                    function CreateExampleEntityResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return CreateExampleEntityResponse;
                }(DataService_1.DataServiceResponse));
                BoundController.CreateExampleEntityResponse = CreateExampleEntityResponse;
                var CreateExampleEntityRequest = (function (_super) {
                    __extends(CreateExampleEntityRequest, _super);
                    function CreateExampleEntityRequest(entityData) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "BoundController";
                        _this._entityType = "ExampleEntity";
                        _this._method = "CreateExampleEntity";
                        _this._parameters = { entityData: entityData };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        return _this;
                    }
                    return CreateExampleEntityRequest;
                }(DataService_1.DataServiceRequest));
                BoundController.CreateExampleEntityRequest = CreateExampleEntityRequest;
                var UpdateExampleEntityResponse = (function (_super) {
                    __extends(UpdateExampleEntityResponse, _super);
                    function UpdateExampleEntityResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return UpdateExampleEntityResponse;
                }(DataService_1.DataServiceResponse));
                BoundController.UpdateExampleEntityResponse = UpdateExampleEntityResponse;
                var UpdateExampleEntityRequest = (function (_super) {
                    __extends(UpdateExampleEntityRequest, _super);
                    function UpdateExampleEntityRequest(unusualEntityId, updatedEntity) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "BoundController";
                        _this._entityType = "ExampleEntity";
                        _this._method = "UpdateExampleEntity";
                        _this._parameters = { updatedEntity: updatedEntity };
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        _this._keys = { UnusualEntityId: unusualEntityId };
                        return _this;
                    }
                    return UpdateExampleEntityRequest;
                }(DataService_1.DataServiceRequest));
                BoundController.UpdateExampleEntityRequest = UpdateExampleEntityRequest;
                var DeleteExampleEntityResponse = (function (_super) {
                    __extends(DeleteExampleEntityResponse, _super);
                    function DeleteExampleEntityResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return DeleteExampleEntityResponse;
                }(DataService_1.DataServiceResponse));
                BoundController.DeleteExampleEntityResponse = DeleteExampleEntityResponse;
                var DeleteExampleEntityRequest = (function (_super) {
                    __extends(DeleteExampleEntityRequest, _super);
                    function DeleteExampleEntityRequest(unusualEntityId) {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "BoundController";
                        _this._entityType = "ExampleEntity";
                        _this._method = "DeleteExampleEntity";
                        _this._parameters = {};
                        _this._isAction = true;
                        _this._returnType = null;
                        _this._isReturnTypeCollection = false;
                        _this._keys = { UnusualEntityId: unusualEntityId };
                        return _this;
                    }
                    return DeleteExampleEntityRequest;
                }(DataService_1.DataServiceRequest));
                BoundController.DeleteExampleEntityRequest = DeleteExampleEntityRequest;
                var GetAllExampleEntitiesResponse = (function (_super) {
                    __extends(GetAllExampleEntitiesResponse, _super);
                    function GetAllExampleEntitiesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetAllExampleEntitiesResponse;
                }(DataService_1.DataServiceResponse));
                BoundController.GetAllExampleEntitiesResponse = GetAllExampleEntitiesResponse;
                var GetAllExampleEntitiesRequest = (function (_super) {
                    __extends(GetAllExampleEntitiesRequest, _super);
                    function GetAllExampleEntitiesRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "BoundController";
                        _this._entityType = "ExampleEntity";
                        _this._method = "GetAllExampleEntities";
                        _this._parameters = {};
                        _this._isAction = false;
                        _this._returnType = DataServiceEntities_g_1.Entities.ExampleEntity;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetAllExampleEntitiesRequest;
                }(DataService_1.DataServiceRequest));
                BoundController.GetAllExampleEntitiesRequest = GetAllExampleEntitiesRequest;
            })(BoundController || (BoundController = {}));
            exports_1("BoundController", BoundController);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/DataService/DataServiceRequests.g.js.map