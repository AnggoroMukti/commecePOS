﻿
/* tslint:disable */
import { ProxyEntities } from "PosApi/Entities";

import { Entities } from "./ITK_DeliveryOrderEntities.g";

import { DataServiceRequest, DataServiceResponse } from "PosApi/Consume/DataService";
export { ProxyEntities };

export { Entities };

export namespace ITK_DOController {
    // Entity Set ExampleEntity
    
    
    export class GetAllExampleEntitiesResponse extends DataServiceResponse {
        public result: Entities.DOEntity[];
    }

    export class GetAllExampleEntitiesRequest<TResponse extends GetAllExampleEntitiesResponse> extends DataServiceRequest<TResponse> {
        /**
         * Constructor
         */
        public constructor() {
            super();

            this._entitySet = "ITK_DeliveryOrderController";
            this._entityType = "ITK_DeliveryOrderEntity";
            this._method = "GetAllDONoEntities";
            this._parameters = {};
            this._isAction = false;
            this._returnType = Entities.DOEntity;
            this._isReturnTypeCollection = true;

        }
    }

}