System.register(["PosApi/Entities", "./ITK_DeliveryOrderEntities.g", "PosApi/Consume/DataService"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Entities_1, ITK_DeliveryOrderEntities_g_1, DataService_1, ITK_DOController;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Entities_1_1) {
                Entities_1 = Entities_1_1;
            },
            function (ITK_DeliveryOrderEntities_g_1_1) {
                ITK_DeliveryOrderEntities_g_1 = ITK_DeliveryOrderEntities_g_1_1;
            },
            function (DataService_1_1) {
                DataService_1 = DataService_1_1;
            }
        ],
        execute: function () {
            exports_1("ProxyEntities", Entities_1.ProxyEntities);
            exports_1("Entities", ITK_DeliveryOrderEntities_g_1.Entities);
            (function (ITK_DOController) {
                var GetAllExampleEntitiesResponse = (function (_super) {
                    __extends(GetAllExampleEntitiesResponse, _super);
                    function GetAllExampleEntitiesResponse() {
                        return _super !== null && _super.apply(this, arguments) || this;
                    }
                    return GetAllExampleEntitiesResponse;
                }(DataService_1.DataServiceResponse));
                ITK_DOController.GetAllExampleEntitiesResponse = GetAllExampleEntitiesResponse;
                var GetAllExampleEntitiesRequest = (function (_super) {
                    __extends(GetAllExampleEntitiesRequest, _super);
                    function GetAllExampleEntitiesRequest() {
                        var _this = _super.call(this) || this;
                        _this._entitySet = "ITK_DeliveryOrderController";
                        _this._entityType = "ITK_DeliveryOrderEntity";
                        _this._method = "GetAllDONoEntities";
                        _this._parameters = {};
                        _this._isAction = false;
                        _this._returnType = ITK_DeliveryOrderEntities_g_1.Entities.DOEntity;
                        _this._isReturnTypeCollection = true;
                        return _this;
                    }
                    return GetAllExampleEntitiesRequest;
                }(DataService_1.DataServiceRequest));
                ITK_DOController.GetAllExampleEntitiesRequest = GetAllExampleEntitiesRequest;
            })(ITK_DOController || (ITK_DOController = {}));
            exports_1("ITK_DOController", ITK_DOController);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/DataService/ITK_DeliveryOrderRequests.g.js.map