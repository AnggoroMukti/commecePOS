System.register(["../../DataService/ITK_DeliveryOrderRequests.g", "PosApi/TypeExtensions"], function (exports_1, context_1) {
    "use strict";
    var Messages, TypeExtensions_1, ExampleViewModel;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Messages_1) {
                Messages = Messages_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            }
        ],
        execute: function () {
            ExampleViewModel = (function () {
                function ExampleViewModel(context) {
                    var _this = this;
                    this._context = context;
                    this.title = context.resources.getString("string_0001");
                    this.loadedData = [];
                    this.isItemSelected = function () { return !TypeExtensions_1.ObjectExtensions.isNullOrUndefined(_this._selectedItem); };
                }
                ExampleViewModel.prototype.load = function () {
                    var _this = this;
                    return this._context.runtime
                        .executeAsync(new Messages.ITK_DOController.GetAllExampleEntitiesRequest())
                        .then(function (response) {
                        if (!response.canceled) {
                            _this.loadedData = response.data.result;
                        }
                    });
                };
                return ExampleViewModel;
            }());
            exports_1("default", ExampleViewModel);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/DeliveryOrder/Dialog/ITK_DeliveryOrderDialogModel.js.map