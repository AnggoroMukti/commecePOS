﻿import { AvailableDO } from "../../Entities/DOEntities";

export interface IavailableDODialogResult {
    updatedAvailDO: AvailableDO;
}