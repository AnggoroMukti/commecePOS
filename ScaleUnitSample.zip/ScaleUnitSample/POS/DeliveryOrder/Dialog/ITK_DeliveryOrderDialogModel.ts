﻿import { IExtensionViewControllerContext } from "PosApi/Create/Views";
import { Entities } from "../../DataService/ITK_DeliveryOrderEntities.g";
import * as Messages from "../../DataService/ITK_DeliveryOrderRequests.g";
import { ObjectExtensions } from "PosApi/TypeExtensions";

export default class ExampleViewModel {
    public title: string;
    public loadedData: Entities.DOEntity[];
    public isItemSelected: () => boolean;
    private _selectedItem: Entities.DOEntity;
    private _context: IExtensionViewControllerContext;

    constructor(context: IExtensionViewControllerContext) {
        this._context = context;
        this.title = context.resources.getString("string_0001");
        this.loadedData = [];
        this.isItemSelected = () => !ObjectExtensions.isNullOrUndefined(this._selectedItem);
    }

    public load(): Promise<void> {
        return this._context.runtime
            .executeAsync(new Messages.ITK_DOController.GetAllExampleEntitiesRequest())
            .then(response => {
                if (!response.canceled) {
                    this.loadedData = response.data.result;
                }
            });
    }
}