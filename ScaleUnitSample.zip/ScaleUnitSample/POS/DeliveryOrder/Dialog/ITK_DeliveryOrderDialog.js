System.register(["PosApi/Create/Dialogs", "knockout", "PosApi/TypeExtensions"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Dialogs, knockout_1, TypeExtensions_1, DialogSampleModule;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Dialogs_1) {
                Dialogs = Dialogs_1;
            },
            function (knockout_1_1) {
                knockout_1 = knockout_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            }
        ],
        execute: function () {
            DialogSampleModule = (function (_super) {
                __extends(DialogSampleModule, _super);
                function DialogSampleModule() {
                    var _this = _super.call(this) || this;
                    _this.availableDO = knockout_1.default.observableArray([
                        { doNumber: "DO-00001" },
                        { doNumber: "DO-00002" },
                        { doNumber: "DO-00003" }
                    ]);
                    return _this;
                }
                DialogSampleModule.prototype.onReady = function (element) {
                    knockout_1.default.applyBindings(this, element);
                };
                DialogSampleModule.prototype.open = function () {
                    var _this = this;
                    var promise = new Promise(function (resolve, reject) {
                        _this._resolve = resolve;
                        var option = {
                            title: "Choose Delivery Order to be booked",
                            button1: {
                                id: "btnOK",
                                label: _this.context.resources.getString("OK"),
                                isPrimary: true,
                                onClick: _this.btnOKClickHandler.bind(_this)
                            },
                            button2: {
                                id: "btnCancel",
                                label: _this.context.resources.getString("Cancel"),
                                onClick: _this.btnCancelClickHandler.bind(_this)
                            },
                        };
                        _this.openDialog(option);
                    });
                    return promise;
                };
                DialogSampleModule.prototype.btnOKClickHandler = function () {
                    this.resolvePromise({
                        doNumber: this.selectedAvailDO
                    });
                    return true;
                };
                DialogSampleModule.prototype.btnCancelClickHandler = function () {
                    this.resolvePromise(null);
                    return true;
                };
                DialogSampleModule.prototype.resolvePromise = function (result) {
                    if (TypeExtensions_1.ObjectExtensions.isFunction(this._resolve)) {
                        this._resolve({
                            updatedAvailDO: result
                        });
                    }
                };
                return DialogSampleModule;
            }(Dialogs.ExtensionTemplatedDialogBase));
            exports_1("default", DialogSampleModule);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/DeliveryOrder/Dialog/ITK_DeliveryOrderDialog.js.map