﻿
import * as Dialogs from "PosApi/Create/Dialogs";
import ko from "knockout";
import { AvailableDO } from "../../Entities/DOEntities";
import DeliveryOrderDialogModel from "./ITK_DeliveryOrderDialogModel";
import { Entities } from "../../DataService/ITK_DeliveryOrderEntities.g";
import { IDataList } from "PosApi/Consume/Controls";
import { IavailableDODialogResult } from "./ITK_DeliveryOrderDialogResult";
import { ObjectExtensions } from "PosApi/TypeExtensions";
//import { ClientEntities } from "PosApi/Entities";
//import ITK_DeliveryOrderResponse from "../Operations/ITK_DeliveryOrderResponse";
//import { IExtensionViewControllerContext } from "PosApi/Create/Views";
//import * as Messages from "../../DataService/ITK_DeliveryOrderRequests.g";


type DeliveryOrderDialogResolve = (value: IavailableDODialogResult) => void;
type DeliveryOrderDialogReject = (reason: any) => void;



export default class DialogSampleModule extends Dialogs.ExtensionTemplatedDialogBase {
    public messagePassedToDialog: ko.Observable<string>;

    public availableDO: ko.ObservableArray<AvailableDO>;
    public selectedAvailDO: ko.Observable<AvailableDO>;
    public loadedData: Entities.DOEntity[];
    public readonly viewModel: DeliveryOrderDialogModel;
    public dataList: IDataList<Entities.DOEntity>;
    private _resolve: DeliveryOrderDialogResolve;
    //private _context: IExtensionViewControllerContext;
    

    constructor() {
        super();
        
        this.availableDO = ko.observableArray([
            { doNumber: "DO-00001" },
            { doNumber: "DO-00002" },
            { doNumber: "DO-00003" }
        ]); 
        //this._context.runtime
        //    .executeAsync(new Messages.ITK_DOController.GetAllExampleEntitiesRequest())
        //    .then(response => {
        //        if (!response.canceled) {
        //            this.loadedData = response.data.result;
        //        }
        //    });
        //this.dataList.data = this.viewModel.loadedData;
    }

    public onReady(element: HTMLElement): void {                
        ko.applyBindings(this, element);
           
    }

    //public open(): Promise<IavailableDODialogResult> {
    public open(): Promise<IavailableDODialogResult> {        
        let promise = new Promise<IavailableDODialogResult>(
            (resolve: DeliveryOrderDialogResolve, reject: DeliveryOrderDialogReject) => {
                this._resolve = resolve;
                const option: Dialogs.ITemplatedDialogOptions = {
                    title: "Choose Delivery Order to be booked",
                    button1: {
                            id: "btnOK",
                            label: this.context.resources.getString("OK"),
                            isPrimary: true,
                            onClick: this.btnOKClickHandler.bind(this)
                        },
                        button2: {
                            id: "btnCancel",
                            label: this.context.resources.getString("Cancel"),
                            onClick: this.btnCancelClickHandler.bind(this)
                        },
                };

                this.openDialog(option);
            }
        );

        return promise;
    }
    private btnOKClickHandler(): boolean {
        this.resolvePromise({
            doNumber: this.selectedAvailDO
        });

        return true;
    }

    private btnCancelClickHandler(): boolean {
        // Cancel will return the original value
        // this.resolvePromise(this._originalStoreHour);
        this.resolvePromise(null);
        return true;
    }

    private resolvePromise(result: AvailableDO): void {
        if (ObjectExtensions.isFunction(this._resolve)) {
            this._resolve(<IavailableDODialogResult>{
            //this._resolve(<ITK_DeliveryOrderResponse>{
                updatedAvailDO: result
            });

            this._resolve = null;
        }
    }
    
}