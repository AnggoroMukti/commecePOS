System.register(["PosApi/Create/Operations", "./ITK_DeliveryOrderRequest", "../Dialog/ITK_DeliveryOrderDialog"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Operations_1, ITK_DeliveryOrderRequest_1, ITK_DeliveryOrderDialog_1, ITK_DeliveryOrderRequestHandler;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Operations_1_1) {
                Operations_1 = Operations_1_1;
            },
            function (ITK_DeliveryOrderRequest_1_1) {
                ITK_DeliveryOrderRequest_1 = ITK_DeliveryOrderRequest_1_1;
            },
            function (ITK_DeliveryOrderDialog_1_1) {
                ITK_DeliveryOrderDialog_1 = ITK_DeliveryOrderDialog_1_1;
            }
        ],
        execute: function () {
            ITK_DeliveryOrderRequestHandler = (function (_super) {
                __extends(ITK_DeliveryOrderRequestHandler, _super);
                function ITK_DeliveryOrderRequestHandler() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                ITK_DeliveryOrderRequestHandler.prototype.supportedRequestType = function () {
                    return ITK_DeliveryOrderRequest_1.default;
                };
                ITK_DeliveryOrderRequestHandler.prototype.executeAsync = function (request) {
                    var _this = this;
                    this.context.logger.logInformational("Log message from ITK_DeliveryOrderRequestHandler executeAsync().", this.context.logger.getNewCorrelationId());
                    var dialog = new ITK_DeliveryOrderDialog_1.default();
                    return dialog.open().then(function (result) {
                        if (result.updatedAvailDO) {
                            _this.context.logger.logInformational("User canceled the operation.");
                            return {
                                canceled: true,
                                data: null,
                            };
                        }
                        _this.context.logger.logInformational("Operation completed successfully.");
                        return {
                            canceled: false,
                            data: result.updatedAvailDO,
                        };
                    }, function (error) {
                        _this.context.logger.logError("Error during dialog operation: " + error);
                        return {
                            canceled: true,
                            data: null,
                        };
                    });
                };
                return ITK_DeliveryOrderRequestHandler;
            }(Operations_1.ExtensionOperationRequestHandlerBase));
            exports_1("default", ITK_DeliveryOrderRequestHandler);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/DeliveryOrder/Operations/ITK_DeliveryOrderRequestHandler.js.map