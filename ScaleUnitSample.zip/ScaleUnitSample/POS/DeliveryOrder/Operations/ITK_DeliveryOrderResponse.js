System.register(["PosApi/Create/RequestHandlers"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var RequestHandlers_1, ITK_DeliveryOrderResponse;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (RequestHandlers_1_1) {
                RequestHandlers_1 = RequestHandlers_1_1;
            }
        ],
        execute: function () {
            ITK_DeliveryOrderResponse = (function (_super) {
                __extends(ITK_DeliveryOrderResponse, _super);
                function ITK_DeliveryOrderResponse() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return ITK_DeliveryOrderResponse;
            }(RequestHandlers_1.Response));
            exports_1("default", ITK_DeliveryOrderResponse);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/DeliveryOrder/Operations/ITK_DeliveryOrderResponse.js.map