﻿import { ExtensionOperationRequestBase } from "PosApi/Create/Operations";
import ITK_DeliveryOrderResponse from "./ITK_DeliveryOrderResponse";

/**
 * (Sample) Operation request for executing end of day operations.
 */
export default class ITK_DeliveryOrderRequest<TResponse extends ITK_DeliveryOrderResponse> extends ExtensionOperationRequestBase<TResponse> {
    constructor(correlationId: string) {
        super(5002, correlationId);
    }
}