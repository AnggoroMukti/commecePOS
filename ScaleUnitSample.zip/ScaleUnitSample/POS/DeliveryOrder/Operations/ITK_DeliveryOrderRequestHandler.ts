﻿import { ExtensionOperationRequestType, ExtensionOperationRequestHandlerBase } from "PosApi/Create/Operations";
import { ClientEntities } from "PosApi/Entities";
import ITK_DeliveryOrderResponse from "./ITK_DeliveryOrderResponse";
import ITK_DeliveryOrderRequest from "./ITK_DeliveryOrderRequest";
import DeliveryOrder from "../Dialog/ITK_DeliveryOrderDialog";
import { IavailableDODialogResult } from "../Dialog/ITK_DeliveryOrderDialogResult";
//import MessageDialog from "../Dialog/DeliveryOrderDialog";


/**
 * (Sample) Request handler for the EndOfDayOperationRequest class.
 */



export default class ITK_DeliveryOrderRequestHandler extends ExtensionOperationRequestHandlerBase<ITK_DeliveryOrderResponse> {
    /**
     * Gets the supported request type.
     * @return {RequestType<TResponse>} The supported request type.
     */
    public supportedRequestType(): ExtensionOperationRequestType<ITK_DeliveryOrderResponse> {
        return ITK_DeliveryOrderRequest;
    }

    /**
     * Executes the request handler asynchronously.
     * @param {ITK_DeliveryOrderRequest<TResponse>} request The request.
     * @return {Promise<ICancelableDataResult<TResponse>>} The cancelable async result containing the response.
     */
    //public executeAsync(
    //printRequest: ITK_DeliveryOrderRequest<ITK_DeliveryOrderResponse>)
    //: Promise<ClientEntities.ICancelableDataResult<ITK_DeliveryOrderResponse>> {

    //    this.context.logger.logInformational("Log message from PrintOperationRequestHandler executeAsync().", this.context.logger.getNewCorrelationId());

    //    //let dialog: DeliveryOrder = new DeliveryOrder();
    //    //dialog.open()
    //    //    .then((result: ClientEntities.ICancelableDataResult<ITK_DeliveryOrderResponse>) => {
    //    //        //: Promise<void>
    //    //        return Promise.resolve({
    //    //            canceled: true,
    //    //            data: null
    //    //        });
    //    //    })

    //    let message: string = "Test Message Dialog";
    //    MessageDialog.show(this.context, message);

    //    return Promise.resolve({
    //        canceled: true,
    //        data: null
    //    });
    //}

    public executeAsync(
        request: ITK_DeliveryOrderRequest<ITK_DeliveryOrderResponse>
    ): Promise<ClientEntities.ICancelableDataResult<ITK_DeliveryOrderResponse>> {

        this.context.logger.logInformational(
            "Log message from ITK_DeliveryOrderRequestHandler executeAsync().",
            this.context.logger.getNewCorrelationId()
        );

        const dialog = new DeliveryOrder();

        return dialog.open().then(
            (result: IavailableDODialogResult) => {
                if (result.updatedAvailDO) {
                    this.context.logger.logInformational("User canceled the operation.");
                    return {
                        canceled: true,
                        data: null,
                    };
                }

                this.context.logger.logInformational("Operation completed successfully.");
                return {
                    canceled: false,
                    data: result.updatedAvailDO as unknown as ITK_DeliveryOrderResponse,
                };
            },
            (error: any) => {
                this.context.logger.logError("Error during dialog operation: " + error);
                return {
                    canceled: true,
                    data: null,
                };
            }
        );
    }


    //public executeAsync(
    //    request: ITK_DeliveryOrderRequest<ITK_DeliveryOrderResponse>
    //): Promise<ClientEntities.ICancelableDataResult<ITK_DeliveryOrderResponse>> {

    //    this.context.logger.logInformational(
    //        "Log message from ITK_DeliveryOrderRequestHandler executeAsync().",
    //        this.context.logger.getNewCorrelationId()
    //    );

    //    const dialog = new DeliveryOrder();

    //    return dialog.open();
    //}














    //public executeAsync(
    //    request: ITK_DeliveryOrderRequest<ITK_DeliveryOrderResponse>
    //): Promise<ClientEntities.ICancelableDataResult<ITK_DeliveryOrderResponse>> {
    //    this.context.logger.logInformational(
    //        "Log message from ITK_DeliveryOrderRequestHandler executeAsync().",
    //        this.context.logger.getNewCorrelationId()
    //    );

    //    const dialog = new DeliveryOrder();

    //    // Set a timeout for dialog to prevent blocking if it's taking too long
    //    const timeout = new Promise<ClientEntities.ICancelableDataResult<ITK_DeliveryOrderResponse>>((_, reject) => {
    //        setTimeout(() => {
    //            reject("Dialog operation timed out.");
    //        }, 10000); // Timeout after 10 seconds
    //    });

    //    // Run dialog and timeout in parallel and return whichever resolves first
    //    return Promise.race([
    //        dialog.open().then(
    //            (result: IavailableDODialogResult) => {
    //                if (result.updatedAvailDO) {
    //                    this.context.logger.logInformational("User canceled the operation.");
    //                    return {
    //                        canceled: true,
    //                        data: null,
    //                    };
    //                }

    //                // Assuming updatedAvailDO is of type ITK_DeliveryOrderResponse
    //                if (result.updatedAvailDO && this.isDeliveryOrderResponse(result.updatedAvailDO)) {
    //                    this.context.logger.logInformational("Operation completed successfully.");
    //                    return {
    //                        canceled: false,
    //                        data: result.updatedAvailDO,
    //                    };
    //                }

    //                // In case of an unexpected result
    //                this.context.logger.logError("Invalid response data.");
    //                return {
    //                    canceled: true,
    //                    data: null,
    //                };
    //            },
    //            (error: any) => {
    //                this.context.logger.logError("Error during dialog operation: " + error);
    //                return {
    //                    canceled: true,
    //                    data: null,
    //                };
    //            }
    //        ),
    //        timeout // Wait for the timeout to reject if it's taking too long
    //    ]);
    //}

    ///**
    // * Type guard to check if an object is of type ITK_DeliveryOrderResponse.
    // * @param obj The object to check.
    // * @return {boolean} True if the object is of type ITK_DeliveryOrderResponse.
    // */
    //private isDeliveryOrderResponse(obj: any): obj is ITK_DeliveryOrderResponse {
    //    return obj && typeof obj === 'object' && 'someProperty' in obj; // Adjust the check based on actual properties of ITK_DeliveryOrderResponse
    //}

}