﻿import ITK_DeliveryOrderResponse from "./ITK_DeliveryOrderResponse";
import ITK_DeliveryOrderRequest from "./ITK_DeliveryOrderRequest";
import { ExtensionOperationRequestFactoryFunctionType, IOperationContext } from "PosApi/Create/Operations";
import { ClientEntities } from "PosApi/Entities";

let getOperationRequest: ExtensionOperationRequestFactoryFunctionType<ITK_DeliveryOrderResponse> =
    /**
     * Gets an instance of ITK_DeliveryOrderRequest.
     * @param {number} operationId The operation Id.
     * @param {string[]} actionParameters The action parameters.
     * @param {string} correlationId A telemetry correlation ID, used to group events logged from this request together with the calling context.
     * @return {ITK_DeliveryOrderRequest<TResponse>} Instance of ITK_DeliveryOrderRequest.
     */
    function (
        context: IOperationContext,
        operationId: number,
        actionParameters: string[],
        correlationId: string
    ): Promise<ClientEntities.ICancelableDataResult<ITK_DeliveryOrderRequest<ITK_DeliveryOrderResponse>>> {
        let operationRequest: ITK_DeliveryOrderRequest<ITK_DeliveryOrderResponse> = new ITK_DeliveryOrderRequest<ITK_DeliveryOrderResponse>(correlationId);
        return Promise.resolve(<ClientEntities.ICancelableDataResult<ITK_DeliveryOrderRequest<ITK_DeliveryOrderResponse>>>{
            canceled: false,
            data: operationRequest
        });
    };
export default getOperationRequest;