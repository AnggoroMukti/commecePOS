System.register(["./ITK_DeliveryOrderRequest"], function (exports_1, context_1) {
    "use strict";
    var ITK_DeliveryOrderRequest_1, getOperationRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (ITK_DeliveryOrderRequest_1_1) {
                ITK_DeliveryOrderRequest_1 = ITK_DeliveryOrderRequest_1_1;
            }
        ],
        execute: function () {
            getOperationRequest = function (context, operationId, actionParameters, correlationId) {
                var operationRequest = new ITK_DeliveryOrderRequest_1.default(correlationId);
                return Promise.resolve({
                    canceled: false,
                    data: operationRequest
                });
            };
            exports_1("default", getOperationRequest);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/DeliveryOrder/Operations/ITK_DeliveryOrderRequestFactory.js.map