System.register(["PosApi/Create/Operations"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Operations_1, ITK_DeliveryOrderRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Operations_1_1) {
                Operations_1 = Operations_1_1;
            }
        ],
        execute: function () {
            ITK_DeliveryOrderRequest = (function (_super) {
                __extends(ITK_DeliveryOrderRequest, _super);
                function ITK_DeliveryOrderRequest(correlationId) {
                    return _super.call(this, 5002, correlationId) || this;
                }
                return ITK_DeliveryOrderRequest;
            }(Operations_1.ExtensionOperationRequestBase));
            exports_1("default", ITK_DeliveryOrderRequest);
        }
    };
});
//# sourceMappingURL=C:/ITKRetailSDK365/src/ScaleUnitSample/POS/DeliveryOrder/Operations/ITK_DeliveryOrderRequest.js.map